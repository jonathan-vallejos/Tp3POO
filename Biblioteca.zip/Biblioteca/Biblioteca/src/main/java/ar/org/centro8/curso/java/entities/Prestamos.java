package ar.org.centro8.curso.java.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Prestamos {
    private int id_Prestamos;
    private int id_Libro;
    private int id_Usuario;
    private int fechaPrestamo;
    private int fechaDevoluicion;
}
