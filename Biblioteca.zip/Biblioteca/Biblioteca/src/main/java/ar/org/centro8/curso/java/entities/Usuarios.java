package ar.org.centro8.curso.java.entities;

import javax.swing.Spring;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class Usuarios {

    private int id_Usuario;
    private Spring nombre;
    private Spring apellido;
    private int telefono;
    private Spring tipoUsuario;

    
}