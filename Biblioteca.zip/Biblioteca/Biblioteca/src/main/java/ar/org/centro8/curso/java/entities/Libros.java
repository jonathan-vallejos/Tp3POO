package ar.org.centro8.curso.java.entities;

import javax.swing.Spring;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class Libros {
    private int id_Libro;
    private Spring titulo;
    private Spring autor;
    private Spring editorial;
    private Spring genero;
    private boolean disponible;

}
