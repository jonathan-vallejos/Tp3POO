-- Active: 1717026078506@@127.0.0.1@3306@biblioteca

USE biblioteca;

-- Inserción de 10 clientes de ejemplo
INSERT INTO usuarios (nombre, apellido, telefono, tipo_usuario) VALUES
  ('Juan', 'Pérez', '123456789', 'estudiante'),
  ('María', 'González', '987654321', 'profesor'),
  ('Pedro', 'Sánchez', '456789123', 'estudiante'),
  ('Ana', 'Martínez', '789123456', 'admin'),
  ('Luis', 'Fernández', '321654987', 'estudiante'),
  ('Sara', 'Delgado', '654987321', 'profesor'),
  ('Carlos', 'Ramos', '159753852', 'estudiante'),
  ('Lucia', 'Morales', '852741963', 'admin'),
  ('Jorge', 'Gutiérrez', '963852741', 'estudiante'),
  ('Elena', 'Campos', '741852963', 'profesor');

  -- Inserción de 15 libros de ejemplo
INSERT INTO libros (titulo, autor, editorial, genero, disponible) VALUES
  ('Cien años de soledad', 'Gabriel García Márquez', 'Editorial Sudamericana', 'Novela', true),
  ('El hobbit', 'J.R.R. Tolkien', 'Allen & Unwin', 'Fantasía', true),
  ('1984', 'George Orwell', 'Secker and Warburg', 'Distopía', true),
  ('El Principito', 'Antoine de Saint-Exupéry', 'Reynal & Hitchcock', 'Ficción', true),
  ('Orgullo y prejuicio', 'Jane Austen', 'T. Egerton', 'Novela', true),
  ('Harry Potter y la piedra filosofal', 'J.K. Rowling', 'Bloomsbury', 'Fantasía', true),
  ('La Ilíada', 'Homero', 'Imprenta Real', 'Épica', true),
  ('Frankenstein', 'Mary Shelley', 'Lackington, Hughes, Harding, Mavor, & Jones', 'Terror', true),
  ('Crimen y castigo', 'Fiódor Dostoyevski', 'Russkiy Vestnik', 'Novela', true),
  ('El gran Gatsby', 'F. Scott Fitzgerald', 'Charles Scribner\s Sons', 'Novela', true),
  ('Crónicas marcianas', 'Ray Bradbury', 'Doubleday', 'Ciencia ficción', true),
  ('Fahrenheit 451', 'Ray Bradbury', 'Ballantine Books', 'Distopía', true),
  ('El señor de los anillos', 'J.R.R. Tolkien', 'Allen & Unwin', 'Fantasía', true),
  ('Cumbres borrascosas', 'Emily Brontë', 'Thomas Cautley Newby', 'Novela', true),
  ('Drácula', 'Bram Stoker', 'Archibald Constable and Company', 'Terror', true);


INSERT INTO prestamos (id_libro, id_usuario, fecha_prestamo, fecha_devolucion) VALUES
(1, 2, '2023-04-15', '2023-05-01'),
(3, 4, '2023-03-20', '2023-04-05'),
(6, 1, '2023-05-01', '2023-05-15'),
(8, 5, '2023-04-10', '2023-04-25'),
(10, 3, '2023-05-05', '2023-05-20'),
(2, 6, '2023-03-25', '2023-04-10'),
(5, 7, '2023-04-20', '2023-05-05'),
(7, 9, '2023-05-10', '2023-05-25'),
(9, 8, '2023-04-15', '2023-05-01'),
(4, 10, '2023-05-01', '2023-05-15');


