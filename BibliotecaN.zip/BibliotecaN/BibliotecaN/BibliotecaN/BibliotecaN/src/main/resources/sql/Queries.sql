-- Active: 1717886900657@@127.0.0.1@3307@biblioteca

use biblioteca;

SELECT * FROM libros;

SELECT * FROM usuarios;

--Buscar libros por título
SELECT * FROM libros WHERE genero LIKE '%f%';

--Buscar libros por autor
SELECT * FROM libros WHERE autor LIKE '%Tolkien%';

--Buscar libros por género
SELECT * FROM libros WHERE genero = 'Ficción';

--Listar todos los libros disponibles
SELECT * FROM libros WHERE disponible = true;


--Crear un nuevo préstamo
INSERT INTO prestamos (id_libro, id_usuario, fecha_prestamo, fecha_devolucion)
VALUES (1, 2, '2024-05-24', '2024-06-07');

--Marcar un libro como prestado
UPDATE libros SET disponible = false WHERE id_libro = 1;

--Actualizar la información de un préstamo
UPDATE prestamos
SET fecha_devolucion = '2024-06-05'
WHERE id_prestamo = 1;

--Marcar un libro como disponible
UPDATE libros SET disponible = true WHERE id_libro = 1;

--Obtener los libros prestados por un usuario
SELECT l.*, p.fecha_prestamo, p.fecha_devolucion
FROM prestamos p
JOIN libros l ON p.id_libro = l.id_libro
WHERE p.id_usuario = 2;

--Obtener los usuarios que han prestado un libro
SELECT u.*, p.fecha_prestamo, p.fecha_devolucion
FROM prestamos p
JOIN usuarios u ON p.id_usuario = u.id_usuario
WHERE p.id_libro = 1;

--Obtener los libros más prestados
SELECT l.*, COUNT(p.id_prestamo) AS veces_prestado
FROM libros l
LEFT JOIN prestamos p ON l.id_libro = p.id_libro
GROUP BY l.id_libro
ORDER BY veces_prestado DESC;