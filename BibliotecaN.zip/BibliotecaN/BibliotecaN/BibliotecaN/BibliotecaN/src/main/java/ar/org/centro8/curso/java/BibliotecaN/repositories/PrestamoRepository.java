package ar.org.centro8.curso.java.BibliotecaN.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.BibliotecaN.connectors.Connector;
import ar.org.centro8.curso.java.BibliotecaN.entities.Prestamo;

public class PrestamoRepository {
    
    private static Connection conn = Connector.getConnection();

    public void save(Prestamo prestamos){

        if(prestamos==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
            "insert into prestamos (id_prestamo, id_libro, id_usuario, fecha_Prestamo, fecha_Devolucion) values (?,?,?,?,?)",
            PreparedStatement.RETURN_GENERATED_KEYS)){
            ps.setInt(1, prestamos.getId_Prestamo());
            ps.setInt(2, prestamos.getId_Libro());
            ps.setInt(3, prestamos.getId_Usuario());
            ps.setString(4, prestamos.getFecha_Prestamo());
            ps.setString(5, prestamos.getFecha_Devolucion());
            ps.execute();
            ResultSet rs=ps.getGeneratedKeys();
            if(rs.next()) prestamos.setId_Prestamo(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }


    public static void remove(Prestamo prestamos){
        if(prestamos==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
            "delete from prestamos where id_Prestamo =?")){
            ps.setInt(1, prestamos.getId_Prestamo());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }


    public static List<Prestamo>getAll(){
        List<Prestamo> list=new ArrayList();
        try (ResultSet rs=conn
                                .createStatement()
                                .executeQuery("select * from prestamos")){
            while(rs.next()){
                list.add(new Prestamo(
                                    rs.getInt("id_Prestamo"),
                                    rs.getInt("id_Libro"),
                                    rs.getInt("id_Usuario"),
                                    rs.getString("fecha_Prestamo"),
                                    rs.getString("fecha_Devolucion")
                ));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }


    public static Prestamo getById(int id_Prestamo){
        return getAll()
                        .stream()
                        .filter(prestamos->prestamos.getId_Prestamo()==id_Prestamo)
                        .findFirst()
                        .orElse(new Prestamo());
    }


     public static List<Prestamo>getLikeFecha_Prestamo(String fecha_Prestamo){
        if(fecha_Prestamo==null) return new ArrayList();
        return getAll()
                        .stream()
                        .filter(prestamos->prestamos
                                                .getFecha_Prestamo()
                                                .toLowerCase()
                                                .contains(fecha_Prestamo.toLowerCase()))
                        .toList();
    }


}
