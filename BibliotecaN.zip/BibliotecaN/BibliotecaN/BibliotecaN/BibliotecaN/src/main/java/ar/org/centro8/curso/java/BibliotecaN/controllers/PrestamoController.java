package ar.org.centro8.curso.java.BibliotecaN.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.centro8.curso.java.BibliotecaN.entities.Usuario;
import ar.org.centro8.curso.java.BibliotecaN.repositories.LibroRepository;
import ar.org.centro8.curso.java.BibliotecaN.repositories.UsuarioRepository;

@Controller

public class PrestamoController {

    private String mensaje="Ingrese un nuevo prestamo!";
    private UsuarioRepository usuarioRepository=new UsuarioRepository();
    private LibroRepository libroRepository=new LibroRepository();

    @GetMapping("/usuarios")
    public String getUsuarios(Model model, @RequestParam(name = "buscar",defaultValue = "")String buscar){
        Usuario usuario=new Usuario();
        usuario.setTipoUsuario("Estudiante");
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("usuario", usuario);
        model.addAttribute("likeApellido", usuarioRepository.getLikeApellido(buscar));
        model.addAttribute("libros", libroRepository.getAll());
        return "usuarios";
    }


    @PostMapping("/usuarioSave")
    public String usuarioSave(@ModelAttribute Usuario usuario){
        //System.out.println("******************************************");
        //System.out.println(alumno);
        //System.out.println("******************************************");
        usuarioRepository.save(usuario);
        if(usuario.getId_Usuario()>0){
            mensaje="Se guardo el usuario id: "+usuario.getId_Usuario();
        }else{
            mensaje="Error! No se pudo guardar el usuario!";
        }
        return "redirect:usuarios";
    }

}
