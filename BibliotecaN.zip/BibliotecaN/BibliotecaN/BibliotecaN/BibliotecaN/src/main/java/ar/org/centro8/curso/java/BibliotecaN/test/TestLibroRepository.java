package ar.org.centro8.curso.java.BibliotecaN.test;

import ar.org.centro8.curso.java.BibliotecaN.entities.Libro;
import ar.org.centro8.curso.java.BibliotecaN.repositories.LibroRepository;

public class TestLibroRepository {
    public static void main(String[] args) {

        LibroRepository libroRepository=new LibroRepository();

        System.out.println("-- Método .save() --");
        Libro libros=new Libro(
                                    100, 
                                    "Javascript", 
                                    "Rios", 
                                    "Smata", 
                                    "Estudio",
                                    true);
    
        libroRepository.save(libros);
        System.out.println(libros);

        System.out.println("-- Método .getById()");
        System.out.println(libroRepository.getById(5));

        System.out.println("-- Método remove() --");
        libroRepository.remove(libroRepository.getById(100));

        System.out.println("-- Método getLikeTitulo()");
        libroRepository.getLikeAutor("Rios").forEach(System.out::println);

        System.out.println("-- Método .getAll() --");
        libroRepository.getAll().forEach(System.out::println);

    
    }
}
