package ar.org.centro8.curso.java.BibliotecaN.controllers;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.centro8.curso.java.BibliotecaN.entities.Libro;
import ar.org.centro8.curso.java.BibliotecaN.repositories.LibroRepository;

public class LibroController {
    private String mensaje="Ingrese un nuevo libro!";
    private LibroRepository libroRepository = new LibroRepository();

    @GetMapping("/libros")
    public String getCursos(Model model, @RequestParam(name = "buscar",defaultValue = "")String buscar){
        Libro libro=new Libro();
        libro.setEditorial("Editorial Sudamerica");
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("autor", libro);
        model.addAttribute("likeAutor", libroRepository.getLikeAutor(buscar));
        model.addAttribute("libros", libroRepository.getAll());
        return "libros";
    }

    @PostMapping("/libroSave")
    public String libroSave(@ModelAttribute Libro libro){
        //System.out.println("******************************************");
        //System.out.println(curso);
        //System.out.println("******************************************");
        libroRepository.save(libro);
        if(libro.getId_Libro()>0){
            mensaje="Se guardo el libro id: "+libro.getId_Libro();
        }else{
            mensaje="Error! No se pudo guardar el libro!";
        }
        return "redirect:cursos";
    }
}
