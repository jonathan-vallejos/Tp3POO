package ar.org.centro8.curso.java.BibliotecaN.test;

import ar.org.centro8.curso.java.BibliotecaN.entities.Usuario;
import ar.org.centro8.curso.java.BibliotecaN.repositories.UsuarioRepository;

public class TestUsuarioRepository {
    public static void main(String[] args) {
        UsuarioRepository usuarioRepository=new UsuarioRepository();

        System.out.println("-- Método .save() --");
        Usuario usuarios=new Usuario(
                                    0, 
                                    "Jonathan", 
                                    "Vallejos",
                                    1168622092,
                                    "Estudiante");
    
        usuarioRepository.save(usuarios);
        System.out.println(usuarios);

        System.out.println("-- Método .getById()");
        System.out.println(usuarioRepository.getById(3));

        System.out.println("-- Método remove() --");
        usuarioRepository.remove(usuarioRepository.getById(2));

        System.out.println("-- Método getLikeApellido()");
        usuarioRepository.getLikeApellido("jo").forEach(System.out::println);

        System.out.println("-- Método .getAll() --");
        usuarioRepository.getAll().forEach(System.out::println);

    }
}
