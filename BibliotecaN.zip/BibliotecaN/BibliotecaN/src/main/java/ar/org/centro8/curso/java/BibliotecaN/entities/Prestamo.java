package ar.org.centro8.curso.java.BibliotecaN.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Prestamo {
    
    private int id_Prestamo;
    private int id_Libro;
    private int id_Usuario;
    private String fecha_Prestamo;
    private String fecha_Devolucion;

}
