package ar.org.centro8.curso.java.BibliotecaN.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.BibliotecaN.connectors.Connector;
import ar.org.centro8.curso.java.BibliotecaN.entities.Usuario;

public class UsuarioRepository {
    
    private Connection conn = Connector.getConnection();

    public void save(Usuario usuario){

        if(usuario==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
            "insert into usuarios (nombre, apellido, telefono, tipo_Usuario) values (?,?,?,?)",
            PreparedStatement.RETURN_GENERATED_KEYS)){
            ps.setString(1, usuario.getNombre());
            ps.setString(2, usuario.getApellido());
            ps.setInt(3, usuario.getTelefono());
            ps.setString(4, usuario.getTipoUsuario());
            ps.execute();
            ResultSet rs=ps.getGeneratedKeys();
            if(rs.next()) usuario.setId_Usuario(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }


    public void remove(Usuario usuarios){
        if(usuarios==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
            "delete from usuario where id_Usuario =?")){
            ps.setInt(1, usuarios.getId_Usuario());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }


    public List<Usuario>getAll(){
        List<Usuario> list=new ArrayList();
        try (ResultSet rs=conn
                                .createStatement()
                                .executeQuery("select * from usuarios")){
            while(rs.next()){
                list.add(new Usuario(
                                    rs.getInt("id_usuario"), 
                                    rs.getString("nombre"), 
                                    rs.getString("apellido"), 
                                    rs.getInt("telefono"), 
                                    rs.getString("tipo_Usuario")
                ));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }


    public Usuario getById(int id_Usuario){
        return getAll()
                        .stream()
                        .filter(usuario->usuario.getId_Usuario()==id_Usuario)
                        .findFirst()
                        .orElse(new Usuario());
    }

    public List<Usuario>getLikeApellido(String apellido){
        if(apellido==null) return new ArrayList();
        return getAll()
                        .stream()
                        .filter(usuarios->usuarios
                                                .getApellido()
                                                .toLowerCase()
                                                .contains(apellido.toLowerCase()))
                        .toList();
    }

}
