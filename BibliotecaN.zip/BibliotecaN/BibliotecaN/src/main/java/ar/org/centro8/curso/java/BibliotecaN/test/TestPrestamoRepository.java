package ar.org.centro8.curso.java.BibliotecaN.test;

import ar.org.centro8.curso.java.BibliotecaN.entities.Prestamo;
import ar.org.centro8.curso.java.BibliotecaN.repositories.PrestamoRepository;

public class TestPrestamoRepository {
    public static void main(String[] args) {
        PrestamoRepository prestamoRepository=new PrestamoRepository();

        System.out.println("-- Método .save() --");
        Prestamo prestamos=new Prestamo(
                                        210,
                                        10, 
                                        7, 
                                        "2024,05,15",
                                        "2024,07,15");
    
        prestamoRepository.save(prestamos);
        System.out.println(prestamos);

        System.out.println("-- Método .getById()");
        System.out.println(PrestamoRepository.getById(3));

        System.out.println("-- Método remove() --");
        PrestamoRepository.remove(PrestamoRepository.getById(2));

        System.out.println("-- Método getLikefecha_Prestamo()");
        PrestamoRepository.getLikeFecha_Prestamo("2023-04").forEach(System.out::println);

        System.out.println("-- Método .getAll() --");
        PrestamoRepository.getAll().forEach(System.out::println);

    }
}
