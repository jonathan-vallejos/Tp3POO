-- Active: 1718230037998@@127.0.0.1@3306@biblioteca

DROP DATABASE if EXISTS biblioteca; 
CREATE DATABASE biblioteca;

-- Uso de la base de datos
USE biblioteca;

-- Creación de la tabla de libros
CREATE TABLE libros (
  id_libro INT AUTO_INCREMENT PRIMARY KEY,
  titulo VARCHAR(100) NOT NULL,
  autor VARCHAR(50) NOT NULL,
  editorial VARCHAR(50) NOT NULL,
  genero VARCHAR(50) NOT NULL,
  disponible BOOLEAN DEFAULT TRUE
);
-- Pruebas


-- Creación de la tabla de usuarios
CREATE TABLE usuarios (
  id_usuario INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(50) NOT NULL,
  apellido VARCHAR(50) UNIQUE NOT NULL,
  telefono VARCHAR(100) NOT NULL,
  tipo_usuario ENUM('estudiante', 'profesor', 'admin') NOT NULL DEFAULT 'estudiante'
);

-- Creación de la tabla de préstamos
CREATE TABLE prestamos (
  id_prestamo INT AUTO_INCREMENT PRIMARY KEY,
  id_libro INT NOT NULL,
  id_usuario INT NOT NULL,
  fecha_prestamo DATE NOT NULL,
  fecha_devolucion DATE NOT NULL,
  FOREIGN KEY (id_libro) REFERENCES libros(id_libro),
  FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
);

-- Creación de índices
CREATE INDEX idx_libros_titulo ON libros(titulo);
CREATE INDEX idx_libros_autor ON libros(autor);
CREATE INDEX idx_usuarios_telefono ON usuarios(telefono);