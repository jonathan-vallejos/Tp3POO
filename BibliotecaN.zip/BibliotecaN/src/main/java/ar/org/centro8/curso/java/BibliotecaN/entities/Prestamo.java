package ar.org.centro8.curso.java.BibliotecaN.entities;

public class Prestamo {
    
    private int id_Prestamos;
    private int id_Libro;
    private int id_Usuario;
    private int fechaPrestamo;
    private int fechaDevoluicion;
}
