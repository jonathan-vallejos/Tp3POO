package ar.org.centro8.curso.java.BibliotecaN.entities;

import javax.swing.Spring;

public class Usuario {
    
    private int id_Usuario;
    private Spring nombre;
    private Spring apellido;
    private int telefono;
    private Spring tipoUsuario;

}
