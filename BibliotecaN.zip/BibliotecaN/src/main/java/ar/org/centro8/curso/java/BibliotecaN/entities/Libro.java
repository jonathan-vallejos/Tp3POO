package ar.org.centro8.curso.java.BibliotecaN.entities;

import javax.swing.Spring;

public class Libro {
    
    private int id_Libro;
    private Spring titulo;
    private Spring autor;
    private Spring editorial;
    private Spring genero;
    private boolean disponible;

}
