package jonathan.biblioteca.java.BibliotecaZ.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import jonathan.biblioteca.java.BibliotecaZ.connectors.Connector;
import jonathan.biblioteca.java.BibliotecaZ.entities.Libro;

public class LibroRepository {

    private Connection conn = Connector.getConnection();


    public void save(Libro libros){

        if(libros==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
            "insert into libros (titulo, autor, editorial, genero, disponible) values (?,?,?,?,?)",
            PreparedStatement.RETURN_GENERATED_KEYS)){
            ps.setString(1, libros.getTitulo());
            ps.setString(2, libros.getAutor());
            ps.setString(3, libros.getEditorial());
            ps.setString(4, libros.getGenero());
            ps.setBoolean(5, libros.isDisponible());
            ps.execute();
            ResultSet rs=ps.getGeneratedKeys();
            if(rs.next()) libros.setId_Libro(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public Libro getById(int id_libro){
        return getAll()
                        .stream()
                        .filter(libro->libro.getId_Libro() == id_libro)
                        .findFirst()
                        .orElse(new Libro());
    }
    

    public void remove(Libro libros){
        if(libros==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
            "delete from libros where id_libro =?")){
            ps.setInt(1, libros.getId_Libro());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }


    public List<Libro>getAll(){
        List<Libro> list=new ArrayList();
        try (ResultSet rs=conn
                                .createStatement()
                                .executeQuery("select * from libros")){
            while(rs.next()){
                list.add(new Libro(
                                    rs.getInt("id_Libro"), 
                                    rs.getString("titulo"), 
                                    rs.getString("autor"), 
                                    rs.getString("editorial"), 
                                    rs.getString("genero"), 
                                    rs.getBoolean("disponible")
                ));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }


    public List<Libro>getLikeTitulo(String titulo){
        if(titulo==null) return new ArrayList();
        return getAll()
                        .stream()
                        .filter(libros->libros
                                                .getTitulo()
                                                .toLowerCase()
                                                .contains(titulo.toLowerCase()))
                        .toList();
    }

}
