package jonathan.biblioteca.java.BibliotecaZ.test;

import jonathan.biblioteca.java.BibliotecaZ.entities.Libro;
import jonathan.biblioteca.java.BibliotecaZ.repositories.LibroRepository;

public class TestLibroRepository {
    public static void main(String[] args) {

        LibroRepository libroRepository=new LibroRepository();

        System.out.println("-- Método .save() --");
        Libro libros=new Libro(
                                    100, 
                                    "Javascript", 
                                    "Rios", 
                                    "Smata", 
                                    "Estudio",
                                    true);
    
        libroRepository.save(libros);
        System.out.println(libros);

        System.out.println("-- Método .getById()");
        System.out.println(libroRepository.getById(5));

        System.out.println("-- Método remove() --");
        libroRepository.remove(libroRepository.getById(100));

        System.out.println("-- Método getLikeTitulo()");
        libroRepository.getLikeTitulo("Rios").forEach(System.out::println);

        System.out.println("-- Método .getAll() --");
        libroRepository.getAll().forEach(System.out::println);

    
    }
}
