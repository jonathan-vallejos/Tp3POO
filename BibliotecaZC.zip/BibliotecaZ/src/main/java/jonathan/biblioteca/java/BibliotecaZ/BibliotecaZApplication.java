package jonathan.biblioteca.java.BibliotecaZ;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BibliotecaZApplication {

	public static void main(String[] args) {
		SpringApplication.run(BibliotecaZApplication.class, args);
	}

}
