package jonathan.biblioteca.java.BibliotecaZ.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class Usuario {
    
    private int id_Usuario;
    private String nombre;
    private String apellido;
    private int telefono;
    private String tipoUsuario;

}
