package jonathan.biblioteca.java.BibliotecaZ.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Libro {
    
    private int id_Libro;
    private String titulo;
    private String autor;
    private String editorial;
    private String genero;
    private boolean disponible;

    
}
