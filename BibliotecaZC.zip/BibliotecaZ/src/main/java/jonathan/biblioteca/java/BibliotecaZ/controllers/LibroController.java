package jonathan.biblioteca.java.BibliotecaZ.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jonathan.biblioteca.java.BibliotecaZ.entities.Libro;
import jonathan.biblioteca.java.BibliotecaZ.repositories.LibroRepository;

@Controller
public class LibroController {

    private String mensaje="Ingrese un nuevo libro!";
    private LibroRepository libroRepository = new LibroRepository();

    @GetMapping("/libros")
    public String getLibros(Model model, @RequestParam(name = "buscar",defaultValue = "")String buscar){
        Libro libro=new Libro();
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("libro", libro);
        model.addAttribute("libro", new Libro());
        model.addAttribute("likeTitulo", libroRepository.getLikeTitulo(buscar));
        return "libros";
    }

    @PostMapping("/libroSave")
    public String libroSave(@ModelAttribute Libro libro){

        libroRepository.save(libro);
        if(libro.getId_Libro()>0){
            mensaje="Se guardo el libro id_Libro: "+libro.getId_Libro();
        }else{
            mensaje="Error! No se pudo guardar el libro!";
        }
        return "redirect:libros";
    }
}
