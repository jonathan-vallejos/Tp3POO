package jonathan.biblioteca.java.BibliotecaZ.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jonathan.biblioteca.java.BibliotecaZ.entities.Usuario;
import jonathan.biblioteca.java.BibliotecaZ.repositories.LibroRepository;
import jonathan.biblioteca.java.BibliotecaZ.repositories.UsuarioRepository;

@Controller

public class UsuarioController {

    private String mensaje="Ingrese un nuevo usuario!";
    private UsuarioRepository usuarioRepository=new UsuarioRepository();
    private LibroRepository libroRepository=new LibroRepository();

    @GetMapping("/usuarios")
    public String getUsuario(Model model, @RequestParam(name = "buscar",defaultValue = "")String buscar){
        Usuario usuario=new Usuario();
        usuario.setTipoUsuario("Estudiante");
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("usuario", usuario);
        model.addAttribute("likeApellido", usuarioRepository.getLikeApellido(buscar));
        model.addAttribute("libros", libroRepository.getAll());
        return "usuarios";
    }


    @PostMapping("/usuarioSave")
    public String usuarioSave(@ModelAttribute Usuario usuario){

        usuarioRepository.save(usuario);
        if(usuario.getId_Usuario()>0){
            mensaje="Se guardo el usuario id: "+usuario.getId_Usuario();
        }else{
            mensaje="Error! No se pudo guardar el usuario!";
        }
        return "redirect:usuarios";
    }

}
