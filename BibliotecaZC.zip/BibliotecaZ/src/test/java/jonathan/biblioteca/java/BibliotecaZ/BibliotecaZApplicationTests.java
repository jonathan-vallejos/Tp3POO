package jonathan.biblioteca.java.BibliotecaZ;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliotecaZApplicationTests {

	@Test
	void contextLoads() {
	}

}
